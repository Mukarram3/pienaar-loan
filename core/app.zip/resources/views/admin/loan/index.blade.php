@extends('admin.layouts.app')
@section('panel')
    <div class="row">
        <div class="col-lg-12">
            <div class="card ">
                <div class="card-body p-0">
                    <div class="table-responsive--lg table-responsive">
                        <table class="table--light style--two table">
                            <thead>
                                <tr>
                                    <th>@lang('S.N.')</th>
                                    <th>@lang('Loan No.') | @lang('Plan')</th>
                                    <th>@lang('User')</th>
                                    <th>@lang('Amount')</th>
                                    <th>@lang('Instalment Amount')</th>
                                    <th>@lang('Instalments')</th>
                                    <th>@lang('Created') | </brs> @lang('Next Instalment')</th>
                                    <th>@lang('Status')</th>
                                    <th>@lang('Action')</th>
                                </tr>
                            </thead>

                            <tbody>
                                @forelse($loans as $loan)
                                    <tr>
                                        <td>{{ __($loop->index + $loans->firstItem()) }}</td>
                                        <td>
                                            <span class="fw-bold">{{ __($loan->loan_number) }}</span>
                                            <span class="d-block text--info">{{ __($loan->plan->name) }}</span>
                                        </td>
                                        <td>
                                            <span class="fw-bold d-block">{{ $loan->user->account_number }}</span>
                                            <span class="small">
                                                <a
                                                    href="{{ route('admin.users.detail', $loan->user_id) }}"><span>@</span>{{ $loan->user->username }}</a>
                                            </span>
                                        </td>
                                        <td>
                                            <span>{{ showAmount($loan->amount) }}</span>
                                            <span class="d-block text--info">
                                                {{ showAmount($loan->payable_amount) }}
                                                @lang('Receivable')
                                            </span>
                                        </td>

                                        <td>
                                            <span>{{ showAmount($loan->per_installment) }}</span>
                                            <span class="d-block text--info">
                                                @lang('Per') {{ $loan->installment_interval }} @lang('days')
                                            </span>
                                        </td>

                                        <td>
                                            <span>@lang('Total') : {{ $loan->total_installment }}</span>
                                            <span class="d-block text--info">@lang('Paid') :
                                                {{ $loan->given_installment }}</span>
                                        </td>

                                        <td>
                                            <span class="d-block">{{ showDateTime($loan->created_at, 'd M, Y') }}</span>
                                            @if ($loan->nextInstallment)
                                                <span class="text--info">
                                                    {{ showDateTime($loan->nextInstallment->installment_date, 'd M, Y') }}
                                                </span>
                                            @else
                                                <span class="text--info">@lang('N\A')</span>
                                            @endif
                                        </td>

                                        <td>
                                            @php echo $loan->status_badge; @endphp
                                        </td>

                                        <td>
                                            <div class="button--group">
                                                <a class="btn btn-sm btn-outline--primary"
                                                    href="{{ route('admin.loan.details', $loan->id) }}">
                                                    <i class="las la-desktop"></i> @lang('Details')
                                                </a>

                                                <a class="btn btn-sm btn-outline--success"
                                                    href="{{ route('admin.loan.installments', $loan->id) }}">
                                                    <i class="las la-history"></i> @lang('Instalments')
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td class="text-center" colspan="100%">{{ __($emptyMessage) }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if ($loans->hasPages())
                    <div class="card-footer py-4">
                        {{ paginateLinks($loans) }}
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection

@push('breadcrumb-plugins')
    <x-search-form dateSearch='yes' placeholder="Loan No." />
@endpush
